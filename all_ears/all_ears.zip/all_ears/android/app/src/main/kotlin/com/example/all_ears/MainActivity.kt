package com.example.all_ears

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
